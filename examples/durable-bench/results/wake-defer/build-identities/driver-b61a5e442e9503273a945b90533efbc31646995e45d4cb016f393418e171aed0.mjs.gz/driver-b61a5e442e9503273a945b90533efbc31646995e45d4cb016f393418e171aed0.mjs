// examples/durable-bench/results/wake-defer/network/ids.ts
import { createHash } from "node:crypto";
var opaqueId = (value) => createHash("sha256").update(value).digest("hex");

// examples/durable-bench/results/wake-defer/network/driver.ts
var errorText = (cause) => cause instanceof Error ? cause.stack ?? cause.message : String(cause);
var driver_default = {
  async fetch(request, env) {
    if (!env.TOKEN || request.headers.get("authorization") !== `Bearer ${env.TOKEN}`)
      return new Response("unauthorized", { status: 401 });
    const url = new URL(request.url);
    if (url.pathname === "/health") return Response.json({ ok: true, version: opaqueId(env.VERSION.id), buildId: env.BUILD_ID });
    if (!["/run", "/seed", "/identity", "/reset", "/cold", "/drain"].includes(url.pathname))
      return new Response("not found", { status: 404 });
    const destination = new URL(url.pathname + url.search, env.TARGET_URL);
    if (destination.protocol !== "https:") throw new Error("HTTPS target required");
    const body = request.method === "GET" ? void 0 : await request.arrayBuffer();
    const startedMs = Date.now();
    const start = performance.now();
    try {
      const response = await fetch(destination, {
        method: request.method,
        headers: { authorization: `Bearer ${env.TOKEN}`, "content-type": "application/json" },
        body,
        signal: AbortSignal.timeout(18e4)
      });
      const raw = await response.text();
      const endedMs = Date.now();
      const workerLatencyMs = performance.now() - start;
      const driver = {
        startedMs,
        endedMs,
        workerLatencyMs,
        version: opaqueId(env.VERSION.id),
        buildId: env.BUILD_ID,
        ingressColo: request.cf?.colo ?? null,
        incomingPlacement: request.headers.get("cf-placement"),
        targetCfRay: response.headers.get("cf-ray"),
        targetPlacement: response.headers.get("cf-placement"),
        receiptBytes: new TextEncoder().encode(raw).byteLength
      };
      let result;
      try {
        result = JSON.parse(raw);
      } catch {
        result = { ok: false, error: raw.slice(0, 2e3) };
      }
      console.log({ wakeDefer: "driver", path: url.pathname, sample: url.searchParams.get("sample"), object: url.searchParams.get("object"), status: response.status, ...driver });
      return Response.json({ ...result, driver }, { status: response.status, headers: { "cache-control": "no-store" } });
    } catch (cause) {
      const driver = { startedMs, endedMs: Date.now(), workerLatencyMs: performance.now() - start, version: opaqueId(env.VERSION.id), buildId: env.BUILD_ID, ingressColo: request.cf?.colo ?? null, incomingPlacement: request.headers.get("cf-placement") };
      const error = errorText(cause);
      console.error({ wakeDefer: "driver-failure", ...driver, error, path: url.pathname, sample: url.searchParams.get("sample") });
      return Response.json({ ok: false, error, driver }, { status: 502 });
    }
  }
};
export {
  driver_default as default
};
